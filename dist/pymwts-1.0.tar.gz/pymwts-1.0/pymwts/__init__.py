__docformat__ = 'restructuredtext'

# Not sure what I need here
from coopr.pyomo import *

#from pandas.version import version as __version__
from pymwts.info import __doc__


