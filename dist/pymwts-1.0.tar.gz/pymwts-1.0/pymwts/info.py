"""
pymwts - a multi-week tour scheduling model implemented in Pyomo
=====================================================================

See BLAH_ for full documentation. Otherwise, see the
docstrings of the various objects in the pymwts namespace:

.. _BLAH: http://hselab.org/ 

*List any classes I create*
"""
